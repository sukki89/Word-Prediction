from pybrain.structure.__init__ import *
