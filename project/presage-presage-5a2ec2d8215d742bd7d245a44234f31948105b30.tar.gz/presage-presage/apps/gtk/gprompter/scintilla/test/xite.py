# -*- coding: utf-8 -*-

import XiteWin

if __name__ == "__main__":
	XiteWin.main("")
